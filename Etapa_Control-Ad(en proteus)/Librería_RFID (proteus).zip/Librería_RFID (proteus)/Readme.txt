Step 1: Open LIBRARY folder and copy MODULO_RF.LIB file, and paste it on proteus LIBRARY folder. i.e

C:\Program Files (x86)\Labcenter Electronics\Proteus 7 Professional\LIBRARY

Step 2: Now open MODELS folder and and copy RX.MDF and TX.MDF and paste it on proteus MODELS folder. i.e


C:\Program Files (x86)\Labcenter Electronics\Proteus 7 Professional\MODELS

Now start your proteus (ISIS) and start making your wireless projects :)

 